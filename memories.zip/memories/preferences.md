# User Preferences
- Prefer diagnostico por logs e leitura de arquivos (terminal/read_file) em vez de ferramentas de visao/imagem.
- Evitar fluxo que dependa de vision quando houver bloqueio organizacional ("vision is not enabled for this organization").


## GCC Macro String Handling
When using gcc `-D` flags with string literals:
- ❌ WRONG: `-DGAME_EXE_FILENAME=\"SLUS_000.67\"` → "missing terminating quote" error
- ✅ RIGHT: `-DGAME_EXE_FILENAME="SLUS_000.67"` (no backslash escaping)
- Wrap each `-D...` in single quotes to prevent shell interpretation: `gcc '-DMACRO="value"' ...`
- NOTE: CMake can generate incorrect escaping in build.ninja. If ninja build fails silently on gcc, check CMakeLists.txt macro definitions.
