# Build Configuration - psxrecomp

## Working Configuration
**MSYS2 ucrt64 + Ninja is the ONLY working setup**
- Compiler: C:\Program Files (x86)\msys64\ucrt64\bin\gcc.exe
- C++: C:\Program Files (x86)\msys64\ucrt64\bin\c++.exe
- Build tool: Ninja
- Generator: `-G Ninja`

## Project Structure
- **Recompiler**: `recompiler/CMakeLists.txt` - Builds PSXRecomp.exe
- **Runner**: `runner/CMakeLists.txt` - Builds game executable (requires generated files)
- **Generated Files**: Located in `generated/` folder at root level
  - tomba_full.c (9.7 MB)
  - tomba_dispatch.c (145 KB)

## Build Commands (CORRECT)
```powershell
# Using MSYS2 ucrt64.exe bash directly
# Recompiler build
& "C:\Program Files (x86)\msys64\ucrt64.exe" bash -lc 'cd /c/Users/Leona/Documents/GitHub/psxrecomp/recompiler && rm -rf build && mkdir build && cd build && cmake -G Ninja -DCMAKE_BUILD_TYPE=Release .. && ninja -j8'

# Runner build (AFTER recompiler OR after tomba_full.c in place)
& "C:\Program Files (x86)\msys64\ucrt64.exe" bash -lc 'export TMPDIR="C:/Temp"; mkdir -p "$TMPDIR"; cd /c/Users/Leona/Documents/GitHub/psxrecomp/runner && rm -rf build && mkdir build && cd build && cmake -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ .. && ninja -j8'
```

## Analysis - GPU-EVENT Blocker

**Finding**: Pass 22 runs ~1873 frames with 0 GPU-EVENT (blackscreen)
- **0x8001A65C** = Called 648 times per session, compiledCommand - only does memory reads
- **0x80015650** = Helper function, 16 bytes, no GPU commands
- **Gate A110 (0x8001A110)** = Dispatcher that calls helper functions, NOT GPU commands
- **Real issue**: NO function in execution chain is sending GPU commands to renderer
- **Status**: Both 0x8001A65C and 0x80015650 are just memory helpers, not GPU dispatchers

**Next Steps**:
- Check if TombaRecomp (same framework, different game) has working GPU-EVENT
- Search for which function SHOULD be sending GPU commands but isn't
- Analyze if game code skips GPU rendering entirely

## Common Issues
1. **Missing tomba_full.c**: Copy from TombaRecomp-master/generated/ if not present
2. **Wrong CMake generator**: Must use `-G Ninja`, NOT Visual Studio
3. **CMake from wrong location**: Use MSYS2's cmake, not system cmake
4. **Permission denied in /tmp**: Set TMPDIR before running cmake: `export TMPDIR=/c/Users/Leona/Temp` (or similar writable path)


## Castlevania 0x80019844 Findings (latest)
- Force-interp depth guard for 0x8001A110 works only if depth++ happens BEFORE `mips_interpret`; otherwise stack overflow loop returns.
- Verified stable run: no crash, `SKIP-A110-RECURSE` fires, but `GPU-MMIO=0` and `GPU-DMA2=0` remain.
- `RAM[0x80032AB0]` callback slot is initially `0x00000000`.
- Even when forcing callback slot to `0x8001A664`, still no GPU writes.
- Forcing direct callback dispatch from 0x80019844 to cb=0x8001A664 increases calls to 0x8001A664 but still yields no GPU-MMIO/GPU-DMA2.
- Forcing interpreter on A664 entry only is stable but still no GPU writes.
- Forcing interpreter on A664 cluster range (0x8001A664..0x8001AB3F) reaches deeper addresses (A860/A91C/A9E0) but returns stack overflow loop without GPU writes.

- Runtime instruction dump in loaded RAM confirms no JALR in `0x80019844..0x80019987` (`[RAM-19844-JALR] none`), supporting that indirect display dispatch path is absent in loaded code.

- Added `PSX_TRACE_CV_DISP_DATA=1` in `runner/src/runtime.c` to trace state snapshots at A110/A664/A860/A91C/A9E0 and transitions in hot loop.
- New telemetry shows hot loop is deterministic `A91C -> A9E0 -> A860` with `a0=0xFFFFFFFF`, while tracked state remains frozen: `0x32AC8=0x8001065C` (w0=`0x536C6443`, w1=`0x00636E79`) and `0x32D68=0x1F801800` (w0/w1=`0`).
- Added optional guard `PSX_GUARD_CV_DISP_LOOP_MAX=<N>` to cap hot-loop calls per frame and avoid runaway recursion during diagnostics.
- With guard set to 200, logs show 200 loop transitions then guard trips; no crash line observed in capture window, and no GPU activity lines appeared before termination.

- CMake Tools may report build failure for `runner/src/runtime.c` without surfacing GCC stderr; when this happens, run `ninja -C build CastlevaniaRecomp -v` with MSYS2 ucrt64 PATH to get the real compiler/linker diagnostics.

- Added `[CV-DISP-WR]` write watchpoint under `PSX_TRACE_CV_DISP_DATA=1` for `0x32AC8/0x32D68` and first two words at their pointed targets.
- In short guarded run (`PSX_GUARD_CV_DISP_LOOP_MAX=200`), `[CV-DISP-WR]` count stayed 0 while loop cycled; this confirms those tracked slots/words are not being updated in the observed blackscreen path.
