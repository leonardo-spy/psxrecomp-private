# GCC Silent Compilation Failure on Windows MSYS2

## Issue
- `C:\PROGRA~2\msys64\ucrt64\bin\gcc.exe` produces exit code 1 with NO error output
- Multiple files fail with identical pattern: GCC exits silently
- Affects glad.c, glfw sources, runtime.c, etc.
- PowerShell stderr redirect yields empty files, Ninja reports "subcommand failed" with no stderr

## Affected System
- Windows 10/11 with MSYS2 (MinGW-w64, UCRT64)
- GCC version 15.2.0 (Rev13, Built by MSYS2 project)
- CMake + Ninja build system

## Probable Causes
1. Missing DLL dependencies for GCC runtime (MSVCRT, libwinpthread, etc.)
2. GCC process hanging/crashing silently without reporting
3. Path/permission issue with temp files during compilation
4. Compiler resource exhaustion or segfault being suppressed

## Workarounds Attempted
- Direct GCC invocation with full paths: No output
- CMake configuration from scratch: No improvement
- Earlier git commits: All fail identically
- PowerShell vs CMD: No difference

## Latest Findings (2026-03-24)
- GCC itself works fine when invoked directly: `gcc test.c -o test.exe` ✅ works
- CMake configuration now succeeds ✅
- **Build fails when Ninja invokes GCC** with silent exit code 1
- Issue is likely: Ninja → GCC communication/output handling
- Possible cause: Ninja version issue (known threading bugs in Win32), or GCC output being killed

## Status  
**CRITICAL BLOCKER** - GCC works standalone but fails under Ninja/CMake. Options:
1. Try different build generator: `cmake -G "Unix Makefiles"` (slower but may avoid Ninja issue)
2. Update/downgrade Ninja version
3. Check eventlog for hidden GCC crashes
4. Use MSVC compiler if available
5. Check GCC installation for missing runtime DLLs


## Root Cause Confirmed (2026-03-24)
- Root cause was missing `ucrt64/bin` in PATH during builds run from generic bash.
- `cc1.exe` failed to load `libzstd.dll` (`error while loading shared libraries: libzstd.dll`).
- GCC then exited with code 1 and effectively no surfaced stderr in Ninja/CMake output.
- Fix: prepend `C:/Program Files (x86)/msys64/ucrt64/bin` to PATH before build.
- Validation: minimal `gcc -c` probe succeeded and full Ninja build (43/43) completed.

- 2026-03-24 (follow-up): `Build_CMakeTools` can still fail with empty diagnostics while manual `ninja -v CastlevaniaRecomp` succeeds after explicitly prepending `/c/PROGRA~2/msys64/ucrt64/bin` to `PATH` in the active terminal.
