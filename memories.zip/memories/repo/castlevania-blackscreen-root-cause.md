# Castlevania Blackscreen Root Cause Analysis

## Discovery: Callback Never Installed

### Evidence
- Real execution (no PSX_FORCE_CV_DISP_CB forcing):
  - A110 called but cb=0x00000000 (NULL, no display callback)
  - Loop A664 never naturally triggered
  - No [CV-DISP-LOOP] events observed
  - Game cycles in A110 vblank loop waiting for callbacks

- With PSX_FORCE_CV_DISP_CB=1 forcing:
  - A664 injected artificially
  - 200+ loop transitions per frame (A860→A91C→A9E0)
  - Lots of writes to GPU data ports
  - Still blackscreen but loop runs

## Root Cause
**The display callback (0x80032AB0) is never initialized during boot.**

Instead of trying to force-inject A664, need to:
1. Find which boot function should register interrupt handler or callback
2. Trace why callback registration fails (hangs? exits early? crashes silently?)
3. Install callback properly so A110's polling finds it

## Next Steps
- Search original game code around boot for callback setup
- Add tracing to interrupt handler installation (0x8003xxxx callback chains)
- Hook `write_word(0x80032AB0)` to catch when callback IS written (if ever)


## New finding: real-entry recursion trap (2026-03-24)
- Enabling `PSX_TRY_REAL_ENTRY=1` enters bootstrap `0x80010DFC`, then repeatedly tail-calls `0x80010E0C` with unchanged state (`ra=0`, `sp=0x801FFF00`, `pc=0`).
- Without mitigation, this causes stack-overflow/segfault before meaningful bootstrap progress.
- Diagnostic workaround added: env-gated breaker `PSX_BOOTSTRAP_BREAK_RECURSION=1` in `call_by_address` aborts this recursion after streak>128.
- With breaker enabled, process no longer crashes and reaches display fallback (`0x800191E0` then `0x80019844`), but output remains black and callback slot still never logs writes/reads.


## New finding: render submission absent in fallback loop (2026-03-24)
- With `PSX_TRACE_RENDER_PIPE=1`, heartbeat at `0x80019844` shows `drawotag=0 addprim=0` for every observed frame.
- Added `PSX_TRACE_RENDER_HOTCALLS=1` sampling in `psx_override_dispatch`: after bootstrap, each frame only re-enters `0x80019844` (frame 0 also has one-time `0x80010DF4`, `0x80010EB8`, `0x800191E0`).
- This indicates the fallback pump is not traversing deeper game/render call chains at all, so no OT submission can occur.
- Suggestion: stop pumping `0x80019844` as a stand-in loop and instead recover the real scheduler/thread path that invokes display/game callbacks (A110/A65C chain or callback registration path at `0x80032AB0`).

## New finding: scheduler C sees all TCB idle (2026-03-24)
- Added env-gated scheduler trace `PSX_TRACE_SCHED_C=1` in `runner/src/runtime.c` for `0x80017024/0x80017078`.
- In fallback pump runs, every call logs `tcb={0,0,0}`, `state2=0`, `state3=0`, callback slot `cb=0x00000000`.
- This confirms scheduler C path is executing, but no thread is ever runnable and callback registration never occurs before/within this loop.
- Practical implication: continue root-cause upstream of scheduler loop (thread setup/state seeding and callback registration init path).

## New finding: bootstrap flow reaches only five unique calls then stalls (2026-03-24)
- Added env-gated `PSX_TRACE_BOOT_FLOW=1` in `runner/src/runtime.c` to log first bootstrap-window dispatches plus unique addresses.
- `build/cv_render_bootflow.log` shows only 5 unique calls in the critical window: `0x80010DF4`, `0x80010EB8`, `0x800191E0`, `0x80019844`, `0x80017078`.
- No `0x800172xx` (or other scheduler/thread init helpers) were observed before the fallback loop settles.
- Scheduler still reports idle forever (`state2=0`, `state3=0`, `tcb={0,0,0}`), no `TCB-W`, callback remains null, render submission stays zero.
- Direction: trace why `0x80017024` path never expands into thread-init setup functions; likely missing branch/return condition after display bootstrap fallback.


## New finding: scheduler branch inputs are permanently zero (2026-03-24)
- Added env-gated `PSX_TRACE_SCHED_BRANCH=1` in `runner/src/runtime.c` to emit `[SCHED-BRANCH]` from the `0x80017024/0x80017078` intercept.
- In `build/cv_sched_branch.log`, all observed fields remain constant zero across calls: `ds/dss/sub2/sub3/timer/ctr`, scratch bytes `{1cc,1ce,1d3,1c6}`, `a5398/99/9A`, `tcb={0,0,0}`, and callback `cb=0`.
- Comparative run with `PSX_CASTLE_PUMP_ENTRY=0x80017024` (`build/cv_sched_branch_17024.log`) still reaches only `0x80017078` (`ra=0x80017034`) with identical zero-state stagnation and no `0x800172xx` calls.
- Direction: issue is upstream of scheduler loop; fallback entry path is not seeding any scheduler/thread state before landing in `0x80017078`.


## New finding: env-name mismatch can hide recursion breaker (2026-03-24)
- The active recursion breaker in `runner/src/runtime.c` reads `PSX_BOOTSTRAP_BREAK_RECURSION` (not `PSX_BOOTSTRAP_RECURSION_BREAK`).
- Runs using only the old name can segfault when `PSX_TRY_REAL_ENTRY=1` enters the `0x80010E0C` recursion trap.
- Using `PSX_BOOTSTRAP_BREAK_RECURSION=1` allows safe return from `0x80010DFC` probe, but still no scheduler seed writes observed.

## New finding: 0x80010DFC is instruction, not bootstrap function entry (2026-03-24)
- In generated Castlevania code, `0x80010DFC` is an instruction inside `func_80010DF4`, while `0x80010EB8` is a proper dispatchable function entry.
- Real-entry fallback default was updated in `runner/src/main_runner.cpp` to use `0x80010EB8` (env override still supported via `PSX_BOOTSTRAP_ENTRY`).
- With `PSX_TRY_REAL_ENTRY=1` and no explicit bootstrap override, run now avoids the `0x80010E0C` recursion trap by default.

## New finding: init writes observed but still no state transition (2026-03-24)
- Expanded seed-write watchpoints to include `0x32A24`, `0x32AA4`, `0x32AB4` (used near `0x80019844`).
- Captures now show writes at `0x32AA4`, but all observed writes are `0x00000000 -> 0x00000000` (no effective state change).
- Scheduler path (`0x80017078`) still enters with all tracked control fields and TCB states at zero.


## New finding: transition-only seed trace shows zero effective transitions (2026-03-24)
- Added filters in `runner/src/runtime.c`:
  - `PSX_TRACE_SCHED_SEED_DELTA_ONLY=1` (only old!=new)
  - `PSX_TRACE_SCHED_SEED_NONZERO_ONLY=1` (skip 0->0 noise)
- With `PSX_TRY_REAL_ENTRY=1` + `PSX_CASTLE_PUMP_ENTRY=0x80017024`, transition-only captures produced **0** `[SCHED-SEED-W]` lines.
- Confirms previous `0x32AA4` traffic was only no-op writes and there is still no first real state transition in watched scheduler/control words.


## New finding: gate trace confirms callback slot alone is insufficient (2026-03-24)
- Added env-gated `PSX_TRACE_SCHED_GATE=1` in `runner/src/runtime.c` (snapshot pre/post around `call_by_address` for `0x80019844/0x8001A110/0x800194F0/0x8001A65C/0x80015308/0x80015650`).
- In `cv_sched_gate.log`, one-shot force callback works (`[FORCE-CB] ... 0x32AB0: 0 -> 0x80032A00`), but every later gate sample at `0x80019844` remains unchanged:
  - `ds/dss/sub2/sub3/timer/ctr = 0`
  - `tcb={0,0,0}`
  - `a5398/99/9A = 0`
  - scratch `{1cc,1ce,1d3,1c6} = 0`
  - render remains `drawotag=0 addprim=0`.
- `0x80019844` is repeatedly entered with `ra=0x8001A184`, proving the upstream caller path is active, but no scheduler/control state is being seeded.
- Practical implication: forcing callback registration is necessary but not sufficient; next focus should be the missing producer that initializes scheduler/control cluster before render submission starts.


## New finding: 0x80019844 table entry is pinned to zero (2026-03-24)
- Added `[SCHED-19844]` probe in `runner/src/runtime.c` under `PSX_TRACE_SCHED_GATE=1` to dump `a0/a1`, `0x32AB4`, `0x32AB0`, `0x32AA4`, and callback table entry `0x32A24 + 4*(a0&0xFF)`.
- In `cv_sched_19844.log`, loop runs with `a0=0`, `a1` settling to `0x80`, `mode(0x32AB4)=0`, callback slot forced to `0x80032A00`, but `tbl[0]` remains `0x00000000` every frame.
- Seed-write trace with `PSX_TRACE_SCHED_SEED_WRITES=1` + `PSX_TRACE_SCHED_SEED_NONZERO_ONLY=1` shows only one relevant non-zero write: forced callback write at `0x32AB0`; no non-zero writes to `0x32A24` or `0x32AA4` were observed.
- This indicates the fallback loop has no valid dispatch target (`tbl[0]==0`) even after callback force, so the core issue is upstream population of the function-pointer table/state machine entry.
## New finding: RA in fallback loop is synthetic from main_runner (2026-03-24)
- `runner/src/main_runner.cpp` sets `cpu.ra` manually when fallback pump is active (`0x80010EA4` for `0x80019844`, otherwise `0x8001A184`).
- This explains why traces repeatedly showed `ra=0x8001A184` even when `0x8001A110` itself never appeared as a dispatched entry.
- Added env override `PSX_CASTLE_PUMP_RA` in `main_runner.cpp` to run controlled RA experiments without code edits.
- Testing `PSX_CASTLE_PUMP_ENTRY=0x80010EB8` with `PSX_CASTLE_PUMP_RA=0` still produced only repeated `0x80010EB8` hits and no new unique bootstrap/game addresses.

## New finding: forcing 0x80019844 gates still does not unlock downstream calls (2026-03-24)
- Added env-gated experiments in `runner/src/runtime.c`:
  - `PSX_FORCE_19844_TBL0` (+ `PSX_FORCE_19844_TBL0_VALUE`)
  - `PSX_FORCE_19844_MODE` (+ `PSX_FORCE_19844_MODE_VALUE`)
- Even with `tbl[0]=0x8001A110` and `mode(0x32AB4)=0x10`, logs still show only repeated `0x80019844` and no `0x8001A110` dispatch (`[SCHED-GATE-OVR]` remains only at `0x800194F0`).
- Render remained stalled (`drawotag=0`, `addprim=0`).
- Implication: current fallback pump path is not reaching/consuming the expected downstream dispatch chain, even when forced state is seeded.

## New finding: real-entry without manual fallback performs no scheduler seeding (2026-03-24)
- Run with `PSX_TRY_REAL_ENTRY=1`, `PSX_BLACKSCREEN_MANUAL_DISPLAY_ENTRY=off`, and `PSX_CASTLE_PUMP_ENTRY=off` executed `0x80010DF4 -> 0x80010EB8` once, then only renderer presents.
- With `PSX_TRACE_SCHED_SEED_WRITES=1` + `PSX_TRACE_SCHED_SEED_NONZERO_ONLY=1`, there were no non-zero seed writes at all in this natural path.
- Confirms bootstrap entry returns before any observed scheduler/control-state population.

## New finding: 0x80010EB8 returns with zero state deltas (2026-03-24)
- Added env-gated pre/post trace in `runner/src/runtime.c` via `PSX_TRACE_BOOT_10EB8=1`.
- Captures (`cv_boot_10eb8_probe.err`, `cv_boot_10eb8_flow_probe.err`) show exactly one `0x80010EB8` call at frame 0.
- PRE and POST snapshots are effectively identical for tracked scheduler/control words:
  - `0x32A00`, `0x32A24`, `0x32AA4`, `0x32AB0`, `0x32AB4`
  - scratch `0x1CC`, `0x1CE`, `0x1D4`, `0x1E8`
  - `sp` delta = 0
- Register outputs do change (`a0/a1/a2/v0`), but no scheduler seed/control transition is produced before returning.
- Implication: `0x80010EB8` itself is not seeding the missing state cluster; the required producer is likely outside this function path (or gated by an unmet precondition before entering it).





## New finding: bootstrap RA override experiments (2026-03-24)
- Added env-gated bootstrap RA override in `runner/src/main_runner.cpp`: `PSX_BOOTSTRAP_RA` seeds `cpu.ra` before calling real bootstrap entry.
- Probe `PSX_BOOTSTRAP_ENTRY=0x80010DFC` + `PSX_BOOTSTRAP_RA=0x80010EA4` (manual/pump off) crashes with segfault before any additional boot-flow hit beyond `0x80010DF4`.
- Probe `PSX_BOOTSTRAP_ENTRY=0x80010EB8` + `PSX_BOOTSTRAP_RA=0x80010EA4` is stable and runs for thousands of host frames, but boot-flow still shows only `0x80010DF4` then one `0x80010EB8` call.
- Implication: RA seeding can change stability, but did not unlock deeper bootstrap/scheduler-seeding calls in the observed natural path.


## New finding: 0x80010EB8 early-return marker + RA sweep + forced continue (2026-03-24)
- Added `[BOOT-10EB8-EARLYRET]` in `runner/src/runtime.c` (under `PSX_TRACE_BOOT_10EB8=1`) to flag flat returns where SP/scheduler-control/scratch snapshots do not change.
- RA sweep with no fallback/pump (`PSX_BOOTSTRAP_ENTRY=0x80010EB8`, RA in `{0, 0x80010EA4, 0x8001994C}`) produced identical pattern:
  - `BOOT-FLOW-UNIQ`: only `0x80010DF4`, `0x80010EB8`
  - `[BOOT-10EB8-EARLYRET]` emitted in all 3 runs
  - no `[SCHED-SEED-W]` non-zero transitions
- Added env-gated forced continuation in `runner/src/main_runner.cpp`:
  - `PSX_BOOTSTRAP_FORCE_CONTINUE`
  - `PSX_BOOTSTRAP_FORCE_CONTINUE_RA`
- Forced calls to `0x800195E0` and `0x80019718` are executed and return (`BOOT-FLOW-UNIQ` includes `n=3`), but still no non-zero scheduler seed writes observed.
- Implication: missing seeding likely depends on prior global/thread state setup, not only reaching these functions once from frame-0 bootstrap context.



## New finding: FORCE-CB hook was short-circuiting 0x80019844 (2026-03-24)
- In `runner/src/runtime.c`, `PSX_FORCE_CALLBACK_INIT` path for `addr==0x80019844` called `0x800194F0` and then exited early (`goto sp_check`), skipping the actual `0x80019844` body.
- Patched hook to inject callback via `psx_dispatch_compiled(cpu, 0x800194F0u)` and continue/fall through to `0x80019844`.
- Post-fix probe (`cv_force_continue_80019844_seeded3.log`) confirms full sequence in one call:
  - writes `0x32AB0 <- 0x80032A00` (forced callback)
  - writes `0x32A24 <- 0x800223A0` (forced tbl0)
  - writes `0x32AB4 <- 0x10` (forced mode)
  - then enters `0x80019844` (`BOOT-FLOW-UNIQ n=4`).
- Despite these seeds and real `0x80019844` execution, run remains black with repeated renderer presents and only no-op `0x32AA4` writes.
- Implication: prior conclusions from FORCE-CB runs that skipped `0x80019844` should be treated cautiously; current blocker is still upstream init/scheduler path beyond simple callback/table/mode seeding.
