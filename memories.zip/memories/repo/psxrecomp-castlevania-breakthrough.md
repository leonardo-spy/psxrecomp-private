# Castlevania Blackscreen - Breakthrough Analysis

## Critical Finding: Gate A110 Opens in Frame 0

**Telemetry Pass 18: Downstream tracking confirmed**

### Gate Opening Event
- **PC**: 0x8001A194 (BNE instruction)
- **Frame**: 0 (during initialization, not boot entry)
- **Condition**: v1=0x00000001, triggering branch (BNE = branch if v1!=0)
- **Next target**: 0x8001A1C4 (skips normal path)

### Downstream Functions Called (Immediately Frame 0)
1. **0x80016074** - Called from pc=0x8001A1CC (delay=0 frames)
2. **0x80016124** - Called from pc=0x8001A220 (delay=0 frames)
3. **0x8001AB2C** - Called from pc=0x8001A228 (delay=0 frames)

### Key Observations
- Default mode: `c2ac-deref` (reads 0x8001F801110 for condition check)
- Gate timing: Early boot, frame 0 - **not during display loop**
- Function chain: All 3 executed sequentially in same frame
- Program status: Crashes after reaching ~frame 980-3500+ (stack overflow)

### Next Investigation Needed
1. What do functions 0x16074, 0x16124, 0x1AB2C return?
2. Is GPU initialization happening?
3. Where is first display loop iteration? (expected 0x800191E0 or variant)
4. Connection between early gate open + late crash?

## Code Changes Applied
- Added flag `g_bs_a110_branch_opened` to track downstream
- Fixed telemetry condition from frame-based to flag-based
- Added capture of 3 downstream functions
- Build: CastlevaniaRecomp-master, Ninja exit=0
- Log: blackscreen_chain_pass18_fixed.log (18MB+, frame 0-980+)

## Technical Notes
- BNE opcode 0x1460000B at 0x8001A194
- c9278 value: 0x000003C1 when branch opens
- c927c value: 0x000003C0 (state counter)
- RAM c2ac: 0x00000000 (source for condition check)
