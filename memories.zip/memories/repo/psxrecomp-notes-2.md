- New findings: `0x80010DF4` should run as compiled path (forcing interpreter for `<0x80022000` was misleading and hit RAM stubs/zeros).
- `call_by_address` callee-fix must not always restore `sp` for boot entry; preserving boot-set `sp` (to `0x80200000`) avoids clobbering startup state.
- Root cause of `PSX_TRY_REAL_ENTRY=1` segfault was interpreter control flow: taken conditional branches were treated as compiled tail-calls. Fixed by keeping taken BEQ/BNE/REGIMM/BLEZ/BGTZ branches local in interpreter.
- Bootstrap `0x80010DFC` now completes loop and exits via `tail_to_compiled target=0x80011104` (~413k steps) instead of crashing.
- For this workspace, reliable build invocation is MSYS2 bash with per-command TMP/TEMP: `TMP=/c/.../.tmp TEMP=/c/.../.tmp cmake --build CastlevaniaRecomp/build -j 8`.
- New finding: in this Castlevania build, several display/startup compiled functions (`0x800191E0`, `0x80019844`) return almost immediately; forcing interpreter on these addresses changes route but still returns without entering DrawOTag/PresentPath.
- Practical build fix in PowerShell: prepend `C:\PROGRA~2\msys64\ucrt64\bin;C:\PROGRA~2\msys64\usr\bin` to `PATH` before `ninja`, otherwise `cc.exe` can fail silently during compile steps.

- Iter53/Iter54: SP-FIX keeps `0x80019844` stable (`jr_ra -> 0x8001A184`), but no DrawOTag/thread markers appear; pumping `0x80019844` or `0x8001A110` from main loop still results in RendererPresent-only black frames.

- Iter55 instrumentation: caller `0x8001A110` now confirmed running in interpreter and repeatedly executing continuation block `0x8001A184..0x8001A1B8`; many invocations hit `reason=guard` at `0x8001A23C` with `ra=0x8001A184`, and stack pointer drifts downward across calls while still no DrawOTag/thread markers.

- Iter58/59: In `0x8001A110`, init stores at `0x8001A160/0x8001A170` execute but source registers are unexpected (`v0=0x1F801BD4`, then `v0=0x8001072C`), so `0x80049278/0x8004927C` remain 0; branch at `0x8001A194` keeps seeing `v1=0`, `v0=0x1F801814`, leading to repeated guard at `0x8001A190` and still no DrawOTag/thread activity.

- Iter309c-trace: env-gated write watch (`PSX_TRACE_309C=1`) in `write_word/write_half/write_byte` shows only one write to `0x8003309C` in short runs (with and without `PSX_CASTLE_BOOT_UNBLOCK`): `phys=0x0003309C old=0 new=0`, RA=`0x801326AC`.
- Static generated code confirms writers of `0x8003309C`: `0x8002711C` clears to zero and `0x8002AC14` writes `a0`; `0x8002ACB4` only reads/polls.

- Porting Tomba's generic "missing fallthrough" scan directly to Castlevania generated C produced massive false positives (hundreds of contiguous block-1 functions), so it is not reliable as a primary black-screen signal without game-specific filtering.
- Implemented a minimal BIOS event table in runner/runtime (Open/Close/Enable/Disable/Deliver/Wait/Test) to replace always-ready stubs; this aligns better with event-driven state transitions like 0x8003309C polling paths.

- Observação prática de debug (usuária): após ~600 frames no cenário atual, quase não surgem eventos novos; para iterações futuras, priorizar janelas até 600 frames e só estender quando houver novo gatilho/instrumentação.
- Event-trace validation after BIOS event-table implementation: pass2 (default timer override) and pass3 (PSX_CASTLE_TIMER_OVERRIDE=0 + PSX_CASTLE_15308_OVERRIDE=1) both produced `event_lines=0`, `bios_b0=0`, `state_309c=0`; runtime still stalls in pre-submit loop (`A110-BR` flood, `NO-GPU-EVENT` only).
- In pass3, guard-loop signal changed (`v0` progressed as small counter values instead of `0x1F801814`), but still no event/309C activity and max observed frame stayed low.


- Iter latest: tracing proved `0x8001A194` is `bne v1,zero,+0x0B` (`instr=0x1460000B`) and the value feeding that branch comes from calls to `0x80015308`.
- Without `PSX_CASTLE_15308_OVERRIDE`, `0x80015308` in mixed dispatch returns MMIO-like values (`v0=0x1F801814`, `c9278=0x1F801BD4`), causing `0x8001A110` to spin until interpreter guard (`reason=guard`, ~100k steps).
- Fix applied in `runner/src/runtime.c`: enable `s_castlevania_15308_override` by default whenever Castlevania overrides are active, still overridable by env (`PSX_CASTLE_15308_OVERRIDE=0/1`).
- After fix, short runs without env override show sane incremental values in `A110-EXIT-COND` (`v0=3,4,5...`, `c9278=0x3C2`) and no guard-loop hit in the same probe window.

- New finding: `0x8001A65C` was still being overridden by `s_castlevania_timer_helpers_override`, returning timer `0x1F801110` instead of RAM `0x80032AB0`; this masked the real state path and produced misleading increasing `v0_after` in DISP traces.
- Runtime adjustment: set `s_castlevania_timer_helpers_override` default to OFF (env `PSX_CASTLE_TIMER_OVERRIDE=1` can re-enable), so default diagnostics reflect original game flow.
- With timer-helper override OFF, `DISP-RET target=0x8001A65C` remains `v0_after=0`, no writes to `0x80032AB0`, and no calls to `0x800194F0` observed in short captures.

- Counter1 ptr-mode recheck: `0x80015308` returns expected pointers (`v0=0x1F801110`, `v1=0x1F801114`), but `A110-EXIT-COND` at `0x8001A194` still logs `will_branch=0` in all sampled iterations.
- Added new env-gated telemetry in `runner/src/runtime.c`: `PSX_TRACE_C2BA=1` logs read/write activity on `0x8003C2BA` (`STATE-C2BA-R/W`) to diagnose why `func_80015650` keeps returning 0.

- Pass5 (`PSX_TRACE_DISP_CALLS_DEEP=1`) removed DISP log truncation (frames >1300 captured) and confirmed no `DISP-CALL` targets to `0x80015770`/`0x80015958` and no `STATE-C2BA-W`; C2BA reads stay `0x0000`.
- New runtime behavior in long trace: after early `A110-EXIT-COND` samples, `0x8001A110` repeatedly guard-exits at `end_pc=0x8001A190` (`steps=100000`, `v1=0x1F8014D0`, `c927c=0x00000F05`) every frame, then returns to `0x80019844` loop without reaching writer path.
- Em PowerShell, Start-Process com ArgumentList em array pode quebrar caminho de ISO/CUE com espaços; para runs automatizados, preferir uma única string com aspas explícitas em ambos os caminhos.
- Iter chain-pass2 (`PSX_TRACE_CHAIN=1`): nenhuma entrada/chamada/retorno para `0x80015694/0x80015770/0x80015958/0x80015AAC/0x80015B58/0x800194F0` (`CHAIN-*=0`) em janela curta válida; `A110-CALL` segue limitado a `0x80015308` e `0x80015650`, `STATE-C2BA-W=0`.
- Ambiente PowerShell desta máquina não tem `rg`; para triagem rápida em logs, usar `Select-String`/`findstr`.

- Bug confirmado em `runner/src/runtime.c`: parsing de `PSX_CASTLE_TIMER_OVERRIDE` só desativava (`'0'`) e nunca ativava; corrigido para aceitar `'1'` (qualquer valor != `'0'`).
- Validação pós-fix: log agora mostra `castlevania timer helper override=1` quando env é `1`; `A65C-OVR` volta a disparar, mas o loop travado em `0x8001A194` persiste (`will_branch=0`, `STATE-C2BA-W=0`, `CHAIN-ENTER/CALL=0`).

- Nova telemetria adicionada em `runner/src/runtime.c`: `PSX_TRACE_C2A8AC=1` rastreia writes que sobrepõem `0x8003C2A8..0x8003C2AF` (`STATE-C2A8AC-W`) em `write_word/write_half/write_byte`.
- Captura curta com `PSX_TRACE_C2A8AC=1` + `A110/C2BA` não registrou nenhum `STATE-C2A8AC-W` e também nenhum `STATE-C2BA-W`; `A110-EXIT-COND` segue com `will_branch=0`.

- Ampliação do trace C2A8AC: adicionado `STATE-C2A8AC-R` em `read_word` com a mesma env (`PSX_TRACE_C2A8AC=1`).
- Resultado: leituras mostram valores estáveis `C2A8=0x1F801814` e `C2AC=0x1F801110` (endereços MMIO de GPU STATUS e Timer1), sem qualquer `STATE-C2A8AC-W` na janela capturada.

- Nova instrumentação no init de Castlevania (`runner/src/runtime.c`): `[BLACKSCREEN][INIT-C2A8AC]` agora loga `mode`, `reason`, `old/new` de C2A8/C2AC e contexto (`hook/ra/sp/frame`).
- Validação pass1 (`blackscreen_init_c2a8ac_pass1.log`): init ocorre em `hook=0x80010DF4` com `reason=default-keep-existing`, mantendo `old==new` (`C2A8=0x1F801814`, `C2AC=0x1F801110`); em seguida `A110-EXIT-COND` permanece `will_branch=0` desde os primeiros ciclos.

- Correlação temporal adicionada: `INIT-A110-DELTA` no bloco `A110-EXIT-COND` (até 20 amostras), usando estado global setado no `INIT-C2A8AC` (`init_hook/init_f/delta_f`).
- Pass counter1 (`blackscreen_init_c2a8ac_counter1_pass1.log`): init troca para `C2A8=0x1F801110`/`C2AC=0x1F801114` (`reason=mode-counter1`), porém `A110-EXIT-COND` continua com `will_branch=0` e `v1=0`; delta inicial confirma que o loop já está travado no mesmo frame do init (`delta_f=0`).

- Pass default comparável (`blackscreen_init_c2a8ac_default_pass2.log`) com nova telemetria confirma o mesmo padrão temporal (`delta_f=0`) e gate fechado (`will_branch=0`), só mudando `v0/c9278` conforme o modo de ponteiro (`default`: `v0=0x1F801814`, `c9278=0x1F801BD4`; `counter1`: `v0=0x1F801110`, `c9278=0x1F8014D0`).

- Pass `blackscreen_v1_c927x_pass1.log` com `PSX_TRACE_C927X=1`: não houve clobber externo de `v1`; a transição para zero ocorre no próprio `0x8001A190` (`instr=0x0062182A`, `slt v1,v1,v0`) com `v1=0x1F801BD4` e `v0=0x1F801814`, portanto `v1` vira `0` por comparação falsa.
- Escritas `STATE-C927X-W`: `0x80039278` recebe `0x1F801BD4` uma vez no init (`A110-INIT`), `0x8003927C` incrementa `0,1,2,...`; assim, o gate `0x8001A194 (bne v1,zero)` permanece fechado por design com esse baseline de `c9278`.

- Nova telemetria `A110-PREINIT` (pass `blackscreen_preinit_pass2.log`) mostrou a origem exata de `c9278`: em `0x8001A158` (`instr=0x244203C0`) ocorre `addiu v0,v0,0x03C0`, transformando `v0` de `0x1F801814` para `0x1F801BD4` antes do store em `0x8001A160` (`AC229278`).
- Pass espelho `counter1` (`blackscreen_preinit_counter1_pass3.log`): mesma sequência, com base `v0=0x1F801110` e depois `v0=0x1F8014D0` (também +`0x3C0`), gravando `c9278=0x1F8014D0`; ainda assim `0x8001A190 (slt v1,v1,v0)` resulta `v1=0` e `A110-EXIT-COND will_branch=0`.

- Instrumentação nova em [runner/src/runtime.c](runner/src/runtime.c#L4869): evento `15308-OVR` no override de `0x80015308` mostra a fonte imediata de `v0/v1` usada por `A110`.
- Pass `blackscreen_15308ovr_pass4.log`: cadeia fechada `15308-OVR (v0=c2a8)` -> `A110-PREINIT` (`0x8001A158 addiu +0x3C0`) -> store em `c9278` -> `A110-V1-PATH` (`0x8001A190 slt`) -> `A110-EXIT-COND will_branch=0`.
- No cenário capturado, `INIT-C2A8AC` veio em `mode=counter1` (`c2a8=0x1F801110`), então `c9278` virou `0x1F8014D0`; como `c9278 > v0` na comparação, branch segue fechado por construção.

- Validação adicional em default (`blackscreen_15308ovr_default_pass5.log`) após limpar `PSX_CASTLE_TIMER_PTR_MODE`: `15308-OVR` retorna `c2a8=0x1F801814`, `A110-PREINIT` aplica `+0x3C0` -> `c9278=0x1F801BD4`, e `A110-EXIT-COND` permanece `will_branch=0` em todas as amostras.

- Experimento controlado adicionado (`PSX_A110_FORCE_C9278_LT=1`) no loop interpretado de `A110` em [runner/src/runtime.c](runner/src/runtime.c): no PC `0x8001A15C`, força `v0 = c2a8 - 4` antes do store em `0x8001A160`.
- Pass validado (`blackscreen_force_c9278lt_pass7.log`): `c2a8=0x1F801814`, `forced_v0=0x1F801810`, `c9278=0x1F801810` e `A110-EXIT-COND` mudou para `will_branch=1` (`v1=1`).
- Isso confirma causalmente que o branch trava fechado por relação de ordem (`c9278 >= v0`) no baseline; ao inverter (`c9278 < v0`), o desvio abre imediatamente.

- Pass8 não invasivo (`blackscreen_a110_order_pass8.log`) com `PSX_TRACE_A110_ORDER=1` confirmou baseline natural: `A110-ORDER-ADDIU` ocorre uma vez no init (`base_v0=0x1F801814`, `predicted_v0=0x1F801BD4`), `STATE-C927X-W` grava `c9278=0x1F801BD4`, e todas as amostras `A110-ORDER-CMP`/`A110-EXIT-COND` repetem `v0=0x1F801814`, `c9278_lt_v0=0`, `will_branch=0`.
- Conclusão prática: o lock do gate em `0x8001A194` persiste sem qualquer força e sem novas escritas em `c9278` após init; para abrir naturalmente, a correção precisa atuar antes/na origem de `c2a8` e/ou no caminho que define o offset `+0x3C0`.
- Novo experimento no override `0x80015308`: env `PSX_CASTLE_15308_SOURCE_MODE` com modos `ptr` (legado), `deref` e `c2ac-deref`, com log de `src` no evento `15308-OVR`.
- Pass9 (`ptr`) confirmou baseline antigo (`v0_out=0x1F801814`, `c9278=0x1F801BD4`, `will_branch=0`).
- Pass10 (`deref`) mostrou que `c2a8` aponta para `GPUSTAT`: `v0_out=0x1C080000` quase constante; gate segue fechado (`c9278=0x1C0803C0`, `will_branch=0`).
- Pass11 (`c2ac-deref`) deu `v0_out` incremental (`0x00000003, 0x00000004...`) e `c9278=0x000003C2`; no trecho curto ainda `will_branch=0` (sem atingir `v0 >= 0x3C3`).
- Implicação: o problema upstream não é só "deref ou não", mas qual registrador/fonte representa o cronômetro esperado para a comparação em `0x8001A194`.
- Pass11 (`c2ac-deref`) coverage check: `v0_out` observed range was min=2, max=257 (256 samples), still far below threshold to satisfy `c9278 < v0` when `c9278=0x3C2` (requires `v0>=0x3C3`).
- User direction: keep focus on Castlevania flow and treat Tomba artifacts as reference only; end-goal is a dedicated Castlevania project folder mirroring TombaRecomp-style packaging once runtime gate issues are resolved.

- Pass12 long attempt (`blackscreen_15308_src_c2ac_deref_pass12_long.log`) still exited with code 1 and produced the same effective coverage as pass11 (`samples=256`, `v0_out max=257`), with no `will_branch=1`.
- Implication: extending wall-clock runtime alone is not currently increasing the `A110` sample window; need to instrument/alter upstream flow that limits this capture window.

- Key breakthrough (pass13 deep): with `PSX_CASTLE_15308_SOURCE_MODE=c2ac-deref` + `PSX_TRACE_A110_DEEP=1`, `A110-ORDER-CMP` reached `v0=0x000003C3` (`c9278=0x000003C2`) and `A110-EXIT-COND` logged `will_branch=1` at `0x8001A194`; branch then called `0x80016074`, `0x80016124`, and `0x8001AB2C` before clean `A110-EXIT`.
- Implemented default behavior change in `runner/src/runtime.c`: `castlevania_15308_source_mode()` now defaults to `c2ac-deref` (env still supports `ptr|deref|c2ac-deref`), based on validated branch-opening behavior.
- Validation pass14 (no `PSX_CASTLE_15308_SOURCE_MODE` set) confirmed banner `source mode=c2ac-deref` and reproduced one natural `will_branch=1` event at `v0=0x3C3`.

- Pass15 (`blackscreen_postpatch_gpucheck_pass15.log`) with default source mode + deep A110 trace: still got `will_branch=1` once at `v0=0x3C3`, but render-side telemetry stayed `gpu_event=0`, `no_gpu=82`, `renderer_present=31`.
- Packaging milestone: created `CastlevaniaRecomp-master/` as a clean project-style folder (CMake, generated, annotations, scripts, README, isos placeholder) and validated build with Ninja (`CastlevaniaRecomp-master/build/CastlevaniaRecomp.exe`).



## Pass 16-17: Instrumentation Downstream (Em Progresso)

- Adicionadas em runtime.c:
  - Variáveis globais: `g_bs_a110_branch_open_frame`, `g_bs_a110_post_branch_16074|16124|1AB2C`, `g_bs_a110_post_branch_bca7`
  - Telemetria `[A110-BRANCH-OPEN]` em A110-EXIT-COND quando `will_branch=1`
  - Telemetria `[A110-REACH-16074/16124/1AB2C]` em A110-CALL para rastrear chamadas intermediárias
  - Propósito: identificar exatamente onde fluxo de render para entre branch abrir e submissão GPU

- Bloqueador: mudanças em runtime.c precisam de rebuild completo; executável em CastlevaniaRecomp-master foi buildado ANTES das edições
- Próximo: usar bash/MSYS2 para fazer rebuild com `ninja -C build -j8` e então rodar pass16 com `PSX_TRACE_A110_DEEP=1` + `PSX_TRACE_A110_EXIT=1`
