- Running build/recompiler/PSXRecomp.exe directly from PowerShell in this setup can crash with exit -1073741819.
- Stable workaround: run PSXRecomp.exe under MSYS2 UCRT gdb with working directory set to the game project folder.
- Castlevania SOTN USA serial detected from disc: SLUS_000.67.
- runtime.c directly references func_800191E0 and func_8001A954; force these entries in function analysis to avoid link errors.

- On this machine MSYS2 is at C:\Program Files (x86)\msys64; set TMP/TEMP to a writable workspace folder (e.g. /c/.../.tmp) before cmake/ninja or builds fail with permission denied in msys64/tmp.
- Runner launch from plain PowerShell may fail with 0xC0000135 until libgcc_s_seh-1.dll, libstdc++-6.dll, and libwinpthread-1.dll are copied from msys64\ucrt64\bin next to the exe.

- In call_by_address, an early `psx_dispatch_compiled(cpu, addr)` check can bypass later force-interpreter routing for boot/display addresses; skip that early path when diagnosing `0x80010DF4` / `0x800191E0`.
- Current blackscreen trace: `0x80010DF4` starts with `JR $ra` (`0x03E00008`) and returns immediately (target 0), and display path chains `0x800191E0 -> 0x80019214 -> 0x80019224` where `0x80019224` also returns immediately.
- Safe workflow: keep real bootstrap entry test (`0x80010DFC`) behind opt-in env var `PSX_TRY_REAL_ENTRY=1`; default path should skip it because current run still segfaults right after switching from `0x80010DF4`.


- Black-screen debug pitfall: forcing `0x80017024` through `mips_interpret` is misleading here; in observed runs it enters with `a0=0xFFFFFFFF` and exits in 7 steps (`invalid_target=0`), so per-frame calls to this address currently behave like a no-op.
- For Castlevania black-screen, forcing game-specific overrides via `PSX_FORCE_GAME_OVERRIDES=1` currently only changes logging/gating (shows forced mode) and did not by itself activate DrawOTag/render submission.
- Black-screen tracing gotcha: offsets like `-28040` from base `0x80040000` resolve to `0x80039278` (not `0x80049278`); wrong probe addresses can fake a "counter stuck at zero" diagnosis.
- Stability gotcha: broad force-interpret ranges can make short helper stubs (e.g. `0x8001A65C`, `0x80015308`) run past intended boundaries in interpreter mode; prefer targeted force-interp addresses.

- Override gating gotcha: Castlevania-specific hooks must not sit behind the Tomba-only gate; using `PSX_FORCE_GAME_OVERRIDES=1` to reach them also enables unrelated Tomba hooks and can skew runtime behavior.

- Address-hook pitfall for Castlevania base EXE: in generated SLUS_000.67_full.c, regions around 0x8005F1C8, 0x80060B70, and 0x80061728 are NOP-filled, so DrawOTag/libgpu hooks at those fixed addresses may not trigger before overlay code is active.

- Added relocation-resilient blackscreen probe in runtime.c: records recent dynamic call chain and correlates GP0/GP1/DMA2 events; lazy-enables only for Castlevania when PSXRECOMP_DEBUG_BLACKSCREEN=1.

- Relocation-proof probe v2: discovery now expands from dynamic recently-seen display-chain callees (not only fixed anchors), and a per-frame `[NO-GPU-EVENT]` chain snapshot is emitted from display present path when no GP0/GP1/DMA2 event occurred that frame.
- Iter75 (with present-hooked no-event probe): `NO-GPU-EVENT` appears from frame 1 onward, `GPU-EVENT=0`, `DISCOVER=2` (`0x80019844`, `0x8001A65C`); recent chain is dominated by `0x8001A65C` with `0x80019844`, indicating display loop progresses but never reaches GP0/GP1/DMA2 submission path.


- Iter77 A/B (`PSX_CASTLE_TIMER_OVERRIDE`): ON keeps `A65C-OVR` active (44 hits) and `0x8001A110` returns via `jr ra` (`end=0x8001A388`); OFF removes override (`A65C-OVR=0`) but `0x8001A110` repeatedly guard-exits (`end=0x8001A190`, `steps=100000`, `ra=0x8001A184`) and discovers extra callees (`0x80015308`, `0x80015650`). Both modes still show `[NO-GPU-EVENT]` with `[GPU-EVENT]=0`.

- Iter83 experiment: with `PSX_CASTLE_TIMER_OVERRIDE=0` and isolated `PSX_CASTLE_15308_OVERRIDE=1`, `0x8001A110` no longer guard-loops and exits via `jr ra` (like helper-override ON), proving `0x80015308` behavior is the guard-loop trigger. Even then, `[GPU-EVENT]=0` and submit hooks (`0x80060B70`/`0x80046264`) are never hit.

- Iter86 force test (`PSX_CASTLE_FORCE_16940=1`): injected calls to `0x80016940` execute but always exit `reason=invalid_target target=0`, with `instr0=0x24620001`, confirming `0x80016940` is not a safe standalone function entry in this build path.
- Iter87 pointer telemetry in `0x80019844` shows `a1` values decoding to string data (`"CD_sync"`, `"DiskErro"`), indicating this path is likely an error/message routine rather than the real frame-submit loop; this explains persistent `GPU-EVENT=0` when pump fallback targets `0x80019844`.

- Iter89 (`PSX_CASTLE_PUMP_ENTRY=off` + `PSX_BLACKSCREEN_MANUAL_DISPLAY_ENTRY=off`): no calls to manual display entries (`0x800191E0`/`0x80019844`) and no `DISCOVER` activity at all, yet host frames still advance with `NO-GPU-EVENT` and `GPU-EVENT=0`; this means game execution is effectively idle after bootstrap return and the old 0x80019844 pump was masking that by running a likely error routine.

- Added non-bu bootstrap loader path: B0 open/read fallback now tries to attach real data from host path, sim:-stripped path, bin/<basename>, basename, ISO basename, and finally DRA.BIN/dra.bin via new cdrom_stub file APIs before synthetic RAM fallback.
- Added C APIs in cdrom_stub (`psx_cdrom_get_file_size`, `psx_cdrom_read_file`) backed by ISOReader so runtime.c (C) can fetch ISO files without direct C++ coupling.

- Rebuild workaround when `cmake` is missing in PowerShell PATH: run via `C:\Program Files (x86)\msys64\usr\bin\bash.exe -lc` with `export PATH='/ucrt64/bin:/usr/bin:$PATH'`, set `TMP`/`TEMP` to workspace `.tmp`, then `cd /c/.../CastlevaniaRecomp; cmake --build build -j 8` (or `cmake -S . -B build -G Ninja; cmake --build build -j 8` when reconfigure is needed).

- Option1+3 static A/B finding: in Castlevania `generated/castlevania_full.c`, address `0x80060B70` is NOP-filled, while in Tomba `generated/SCUS_942.36_full.c` it has real GPU setup code. Current `runner/src/runtime.c` overlay interpreter only auto-routes `>=0x80098000`, so low overlays in `0x8006xxxx` can be bypassed unless forced to interpreter.

- Nota do usuário: Tomba e Castlevania usam ISOs diferentes; offsets/endereços/valores de runtime podem divergir entre jogos, então comparações A/B devem focar padrão de fluxo (ex.: presença de GPU submit), não igualdade de valores absolutos.

- Trace run with `PSX_TRACE_CALL_CHAIN=1` + `PSX_TRACE_GPU_PATH=1` + `PSX_TRY_REAL_ENTRY=0` shows `CALL-CHAIN=3590` dominated by `0x80019844` (3589 hits) and one `0x80010DF4`; `GPU-MMIO=0`, `GPU-DMA2=0`, and no `0x8006xxxx` dispatches.
- In Castlevania generated code, `func_80019844` and `func_8001A110` are emitted as `Blocks: 1` (`generated/castlevania_full.c`), while Tomba equivalent `func_80019844` is multi-block with branches/calls; this strongly suggests Castlevania is stuck in a degenerate loop path before any GPU submit.
