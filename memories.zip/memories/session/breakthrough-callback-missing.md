# BREAKTHROUGH: Callback Registration Function Never Called

## Chain Discovered
1. **func_8001A110** - reads state (callback slot returns 0)
   - Called from **func_80019844** at address 0x80019944 (JAL 0x8001A110)
   -  **func_800194F0** - writes callback slot (0x32AB0)
   - This function EXISTS in dispatch but is **NEVER CALLED**

## Evidence
- Searched entire castlevania_full.c: 0 calls to func_800194F0
- Searched all logs: 0 invocations found  
- Function appears in dispatch table (line 357 declaration)
- But never triggered during bootstrap or fallback loop

## Root Cause Analysis
The callback registration chain is broken:
- Display wants to use callback (reads at 0x8001A110)
- Callback writer exists (func_800194F0 at 0x800194F0)
- But callback writer is never invoked
- Result: callback slot remains 0x00000000

## Missing Link
Need to find:
1. Which bootstrap function should call callback registration  
2. Is it missing entirely from bootstrap sequence?
3. Is it blocked by a conditional predicate?
4. Is it in an unexecuted code path?

## Next Actions
- Search for interrupt/event handler install sequence
- Check if there's an overlay that should load event setup code
- Instrument to trace which functions SHOULD call func_800194F0
- Compare with real game's callback initialization sequence
