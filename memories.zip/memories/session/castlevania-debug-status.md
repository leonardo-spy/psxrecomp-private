# Castlevania Blackscreen Debug - Session Status

## Goal
Fix Castlevania blackscreen by identifying why display callback (at RAM 0x80032AB0) never gets installed during real boot.

## Key Discovery (CONFIRMED)
- **Without PSX_FORCE_CV_DISP_CB:** A110 spins with cb=0x00000000 (NULL), A664 loop never executes naturally
- **With PSX_FORCE_CV_DISP_CB=1:** Callback artificially injected via env var, A664 runs but GPU still produces no output
- **Root cause:** Callback is never registered during boot - the setup code path that should write to 0x80032AB0 is either missing or not being called

## What Was Being Attempted
1. Add `trace_cv_disp_write()` function to detect writes to callback slot (0x80032AB0)
2. Test with `PSX_TRACE_CV_DISP_DATA=1` to confirm slot never receives non-zero value
3. Trace backward from A110 to find where callback registration should happen (boot/BIOS)

## Current Blocker
**GCC compilation failure:** All C files fail to compile with exit code 1, no error output
- Affects glad.c, glfw source files, runtime.c, etc.
- Silent failure suggests GCC DLL dependency or environment issue
- Reproducible even with previous code reverts

## Files Modified
- `runner/src/runtime.c`: Attempted to add `trace_cv_disp_write()` helper
  - Currently reverted to HEAD (clean) due to build failure
  - Changes were minimal: added static function + 4 calls in write_word/write_half/write_byte

## Next Actions (When Build Fixed)
1. Fix GCC/MSYS2 build environment (likely external to code)
2. Re-apply callback watchpoint patch carefully
3. Run with `PSX_TRACE_CV_DISP_DATA=1` to capture callback slot activity
4. Identify the frame/address where callback SHOULD be installed
5. Search for callback registration code path in generated functions or BIOS

## Time Spent This Session
- 2+ hours: Compilation debugging, multiple approaches
- No progress on actual root cause analysis due to toolchain blockage
