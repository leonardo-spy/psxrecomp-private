# Session Progress: Castlevania Blackscreen Investigation

## Current Status: ✅ Downstream Analysis Active

**Latest Pass**: pass18_fixed.log (3 downstream calls confirmed)

### Completed This Session
1. ✅ Identified breakthrough: `will_branch=1` gate opens frame 0
2. ✅ Fixed telemetria bug (frame comparison issue)
3. ✅ Captured 3 downstream function calls:
   - 0x80016074 (frame 0, delay 0)
   - 0x80016124 (frame 0, delay 0)  
   - 0x8001AB2C (frame 0, delay 0)
4. ✅ Recompiled 2x with telemetry fixes
5. ✅ Generated 18MB+ log with complete trace

### Immediate Next Steps

**[P1] Analyze Return Values from Downstream Functions**
- Extract `[A110-RET]` logs for these 3 functions
- Check v0/v1 values before/after
- Identify which one is causing GPU/rendering issue
- Status: Ready to implement

**[P2] Find Display Loop Entry**
- Trace where 0x800191E0 or display equivalent is called
- Compare with timing of gate opening (frame 0)
- Identify if GPU initialization happens before/after gate

**[P3] GPU Initialization Tracking**
- Add telemetry for GPU state when gate opens
- Monitor if GP0/GP1/DMA2 commands happen
- Correlation with blackscreen?

### Key Facts for Next Developer
- Early boot gate (frame 0) vs late crash (frame 980-3500)
- All 3 functions run synchronously in frame 0
- c2ac=0 when decision made (source derivation issue?)
- Stack overflow crash pattern suggests infinite recursion or memory corruption

### Technical Debt
- No logging between frame 0 and frame 980 - need finer granularity
- Don't know what functions 0x16074/0x16124/0x1AB2C actually do yet
- GPU state not being monitored during gate open

### Logs Generated
- pass16_full.log: 16K (initial with bug)
- pass17_fixed.log: 32K (fix attempt 1)
- pass18_fixed.log: 18M+ (fix attempt 2 - SUCCESS)

## Analysis Results - Pass 18 Complete

### Execution Pattern
- **Frames executed**: 0-1282 (1283 unique frames)
- Program loops indefinitely in display function
- Stack overflow crash at frame ~1282
- GPU activity only frames 3-22 (minimal)

### The Blackscreen Root Cause
Early gate opening (frame 0) → downstream functions return → stuck in display loop
- No GPU commands ever sent
- Program runs indefinitely with no rendering

## Analysis Results - Pass 18 Complete

### Execution Pattern
- **Frames executed**: 0-1282 (1283 unique frames)
- **Program status**: Loop without exit (interpreted), stack overflow at frame ~1282
- **GPU activity**: Frames 3-22 only (minimal, references to 0x1F80 addresses)
- **Display loop**: Repetitive at 0x80019844 → 0x8001A110 → return cycle

### The Blackscreen Root Cause
**Hypothesis**: Early gate opening (frame 0) redirects execution to functions that:
1. Return GPU address (0x1F801020) but never send commands
2. Keep program in display loop without rendering
3. Program stuck in infinite loop until stack exhaustion

### GPU Function Analysis
- **0x80016074**: Pass-through (no side effects)
- **0x80016124**: Pass-through (no side effects)  
- **0x8001AB2C**: Returns v1=0x1F801020 (GPU DATA register address - suspicious!)

### Critical Missing Piece
- No actual GPU commands sent (GP0/GP1)
- No DMA2 transfers
- No VRAM writes
- Program executes indefinitely in display mock loop

### Recommendation
Need to:
1. Patch gate A110 to NOT open (force will_branch=0 always)
2. Or trace what 0x8001AB2C actually does (may be missing initialization)
3. Add GPU command monitoring to detect why commands aren't being sent

## Analysis Results - Pass 18

### Execution Pattern
- **Frames executed**: 0-1282 (1283 unique frames)
- **Program status**: Loop without exit (interpreted), stack overflow at frame ~1282
- **GPU activity**: Frames 3-22 only (minimal, references to 0x1F80 addresses)
- **Display loop**: Repetitive at 0x80019844 → 0x8001A110 → return cycle

### The Blackscreen Root Cause
**Hypothesis**: Early gate opening (frame 0) redirects execution to functions that:
1. Return GPU address (0x1F801020) but never send commands
2. Keep program in display loop without rendering
3. Program stuck in infinite loop until stack exhaustion

### GPU Function Analysis
- **0x80016074**: Pass-through (no side effects)
- **0x80016124**: Pass-through (no side effects)
- **0x8001AB2C**: Returns v1=0x1F801020 (GPU DATA register address - suspicious!)

### Critical Missing Piece
- No actual GPU commands sent (GP0/GP1)
- No DMA2 transfers
- No VRAM writes
- Program executes indefinitely in display mock loop

### Recommendation
Need to:
1. Patch gate A110 to NOT open (force will_branch=0 always)
2. Or trace what 0x8001AB2C actually does (may be missing initialization)
3. Add GPU command monitoring to detect why commands aren't being sent
