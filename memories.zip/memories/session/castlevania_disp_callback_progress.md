# Castlevania Display Callback Debugging - Progress

## Current Session Accomplishments

### ✅ BUILD SYSTEM FIXED
- **Issue:** Ninja + GCC silent compilation failures (exit code 1, zero stderr)
- **Solution:** Verbose output revealed successful build was happening; tool output was truncated
- **Status:** Building now works perfectly with `cmake` + `ninja`
- **Final build:** 43 compilation jobs completed, linking successful, 2.9MB executable

### ✅ INSTRUMENTATION ADDED
- **Target:** RAM offset 0x32AB0 (display callback pointer slot)
- **Added to:** `/runner/src/runtime.c`
- **Watchpoints implemented:**
  1. `write_word()` - traces 32-bit writes to 0x32AB0
  2. `write_half()` - traces 16-bit writes to 0x32AB0, 0x32AB2
  3. `write_byte()` - traces 8-bit writes to 0x32AB0-0x32AB3

- **Output:** Writes to stderr with tag `[CV-DISP-CB]` format:
  ```
  [CV-DISP-CB] WRITE addr=0x80032AB0 val=0x80019ABC f42 ra=0x80010D84
  ```
  Shows: full address, value, frame number, return address (caller)

### ⚠️ THE QUESTION
**Does callback address 0x80032AB0 get written during real boot?**
- Previous analysis: Not written (displays black screen)
- Current status: Ready to test with instrumented build

## What to Do Next
1. Run CastlevaniaRecomp.exe (or launcher)
2. Watch stderr for `[CV-DISP-CB]` messages
3. If messages appear → callback IS installed (unexpected, contradicts black screen)
4. If NO messages → callback NOT installed (confirms current theory, need to trace boot)
5. If callback IS missing, trace back to boot sequence to find where it should be installed

## Build Details
- **Compiler:** GCC 15.2.0 (MSYS2 UCRT64)
- **Build system:** CMake + Ninja
- **Source modified:** runtime.c lines ~622, ~920, ~980
- **Executable:** `/c/Users/Leona/Documents/GitHub/psxrecomp/build/CastlevaniaRecomp.exe` (14:35, 2.9MB)

## Technical Notes
- Uses `fprintf(stderr, ...)` + `fflush(stderr)` for immediate output
- Traces all writes regardless of size (word, half, byte all monitored)
- Includes frame counter and return address for context
- Performance impact: negligible (single address check per write)
